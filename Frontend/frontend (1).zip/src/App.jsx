import { Routes, Route } from "react-router"
import './App.css'
import SheshaDrawrer from './Pages/Drawer'
import Login from "./Pages/Login"
import TruckSheet from "./Pages/TruckSheet"
import CreateTicket from "./Pages/Ticketcreation/ticketcreate"
import OpenTicket from "./Pages/Ticketcreation/openticket/openticket"
import CompleteTicket from "./Pages/Ticketcreation/closedticket/closedticket"
import Admindashboard from "./Pages/Ticketcreation/amindashboard"
import OpenAdminticket from "./Pages/Ticketcreation/openadminticket"
function App() {
  return (
    <>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/Drawer" element={<SheshaDrawrer />} >
          
          <Route path="create-ticket" element={<CreateTicket />} />
          <Route path="open-ticket" element={<OpenTicket />} />
          <Route path="closed-ticket" element={<CompleteTicket />} />
           <Route path="admindashboard" element={<Admindashboard />} />
           <Route path="tickets/:department" element={<OpenAdminticket />} />


        </Route>
      </Routes>
    </>
  )
}

export default App
