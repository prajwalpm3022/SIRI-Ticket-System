import React from 'react'

export default function TruckSheet() {
  return (
    <div>TruckSheet</div>
  )
}
