// import React, { useState } from "react";
// import {
//   Box,
//   Typography,
//   Paper,
//   Drawer,
//   IconButton,
//   TextField,
//   Button
// } from "@mui/material";
// import CloseIcon from "@mui/icons-material/Close";
// import dayjs from "dayjs";

// import TicketFilter from "./ticketfilter";
// import TicketGrid from "./ticketgrid";

// export default function OpenTickets() {
//   const [selectedDate, setSelectedDate] = useState(dayjs());
//   const [selectedTicket, setSelectedTicket] = useState(null);
//   const [chatOpen, setChatOpen] = useState(false);
//   const [message, setMessage] = useState("");

//   const handleTicketClick = (ticket) => {
//     setSelectedTicket(ticket);
//     setChatOpen(true);
//   };

//   return (
//     <Box sx={{ p: 2 }}>

//       <Paper
//         sx={{
//           p: 1,
//           borderRadius: 2,
//           mb: 2,
         
//           color:"#ca9dee"
//         }}
//       >
//         <Typography variant="h4" fontWeight={600}>
//           OPEN TICKETS
//         </Typography>
//       </Paper>

//       <Box sx={{ mb: 4 }}>
//         <TicketFilter
//           selectedDate={selectedDate}
//           setSelectedDate={setSelectedDate}
//         />
//       </Box>

//       <TicketGrid onTicketClick={handleTicketClick} />

//       {/* Chat Drawer */}
//       <Drawer
//         anchor="right"
//         open={chatOpen}
//         onClose={() => setChatOpen(false)}
//       >
//         <Box sx={{ width: 350, p: 2 }}>
//           <Box display="flex" justifyContent="space-between">
//             <Typography variant="h6">
//               Ticket #{selectedTicket?.id}
//             </Typography>
//             <IconButton onClick={() => setChatOpen(false)}>
//               <CloseIcon />
//             </IconButton>
//           </Box>

//           <Box
//             sx={{
//               height: 400,
//               border: "1px solid #eee",
//               borderRadius: 2,
//               p: 2,
//               my: 2,
//               overflowY: "auto",
//               backgroundColor: "#f9f9f9"
//             }}
//           >
//             <Typography variant="body2">
//               👋 Chat started for this ticket.
//             </Typography>
//           </Box>

//           <Box display="flex" gap={1}>
//             <TextField
//               fullWidth
//               size="small"
//               placeholder="Type message..."
//               value={message}
//               onChange={(e) => setMessage(e.target.value)}
//             />
//             <Button
//               variant="contained"
//               onClick={() => setMessage("")}
//             >
//               Send
//             </Button>
//           </Box>
//         </Box>
//       </Drawer>
//     </Box>
//   );
// }

import React, { useState } from "react";
import {
  Box,
  Typography,
  Paper,
  Drawer,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  IconButton,
  TextField,
  Button
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import dayjs from "dayjs";

import TicketFilter from "./ticketfilter";
import TicketGrid from "./ticketgrid";

export default function OpenTickets() {

  const [selectedDate, setSelectedDate] = useState(dayjs());
  const [selectedTicket, setSelectedTicket] = useState(null);

  const [chatOpen, setChatOpen] = useState(false);
  const [uploadOpen, setUploadOpen] = useState(false);
  const [optionOpen, setOptionOpen] = useState(false);   // ✅ NEW

  const [message, setMessage] = useState("");
  const [chatMessages, setChatMessages] = useState([]);
  const [file, setFile] = useState(null);

  // ✅ Handle row click
  const handleTicketClick = (ticket) => {
    setSelectedTicket(ticket);

    if (ticket.status === "Attachment Required") {
      setOptionOpen(true);     // 👈 show options first
    } else {
      setChatMessages([]);
      setChatOpen(true);
    }
  };

  return (
    <Box sx={{ p: 2 }}>

      {/* Header */}
      <Paper sx={{ p: 1, borderRadius: 2, mb: 2, color: "#c08bee" }}>
        <Typography variant="h4" fontWeight={600}>
          OPEN TICKETS
        </Typography>
      </Paper>

      {/* Filter */}
      <Box sx={{ mb: 4 }}>
        <TicketFilter
          selectedDate={selectedDate}
          setSelectedDate={setSelectedDate}
        />
      </Box>

      {/* Grid */}
      <TicketGrid onTicketClick={handleTicketClick} />

      {/* ================= OPTION DIALOG ================= */}
      <Dialog
        open={optionOpen}
        onClose={() => setOptionOpen(false)}
      >
        <DialogTitle>
          Ticket #{selectedTicket?.id}
        </DialogTitle>

        <DialogContent>
          <Typography variant="body2">
            This ticket requires an attachment.
            What would you like to do?
          </Typography>
        </DialogContent>

        <DialogActions sx={{ justifyContent: "center", pb: 3 }}>
          <Button
            variant="contained"
            onClick={() => {
              setOptionOpen(false);
              setChatMessages([]);
              setChatOpen(true);
            }}
          >
            Chat with Engineer
          </Button>

          <Button
            variant="outlined"
            onClick={() => {
              setOptionOpen(false);
              setUploadOpen(true);
            }}
          >
            Upload Attachment
          </Button>
        </DialogActions>
      </Dialog>

      {/* ================= CHAT DRAWER ================= */}
      <Drawer
        anchor="right"
        open={chatOpen}
        onClose={() => setChatOpen(false)}
      >
        <Box
          sx={{
            width: 380,
            p: 2,
            display: "flex",
            flexDirection: "column",
            height: "100%"
          }}
        >
          <Box display="flex" justifyContent="space-between">
            <Typography variant="h6">
              Chat - Ticket #{selectedTicket?.id}
            </Typography>
            <IconButton onClick={() => setChatOpen(false)}>
              <CloseIcon />
            </IconButton>
          </Box>

          {/* Chat Area */}
          <Box
            sx={{
              flexGrow: 1,
              border: "1px solid #eee",
              borderRadius: 2,
              p: 2,
              mt: 2,
              mb: 2,
              overflowY: "auto",
              backgroundColor: "#f9f9f9"
            }}
          >
            {chatMessages.length === 0 ? (
              <Typography variant="body2">
                👋 Start conversation with engineer.
              </Typography>
            ) : (
              chatMessages.map((msg, index) => (
                <Box
                  key={index}
                  sx={{
                    textAlign: msg.sender === "user" ? "right" : "left",
                    mb: 1
                  }}
                >
                  <Box
                    sx={{
                      display: "inline-block",
                      px: 2,
                      py: 1,
                      borderRadius: 2,
                      backgroundColor:
                        msg.sender === "user" ? "#1976d2" : "#e0e0e0",
                      color: msg.sender === "user" ? "#fff" : "#000"
                    }}
                  >
                    {msg.text}
                  </Box>
                </Box>
              ))
            )}
          </Box>

          {/* Chat Input */}
          <Box display="flex" gap={1}>
            <TextField
              fullWidth
              size="small"
              placeholder="Type message..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
            />
            <Button
              variant="contained"
              onClick={() => {
                if (!message.trim()) return;

                setChatMessages(prev => [
                  ...prev,
                  { sender: "user", text: message }
                ]);

                setMessage("");

                setTimeout(() => {
                  setChatMessages(prev => [
                    ...prev,
                    { sender: "engineer", text: "Engineer is reviewing your message." }
                  ]);
                }, 1000);
              }}
            >
              Send
            </Button>
          </Box>

        </Box>
      </Drawer>

      {/* ================= UPLOAD DIALOG ================= */}
      <Dialog
        open={uploadOpen}
        onClose={() => setUploadOpen(false)}
      >
        <DialogTitle>
          Upload Attachment - Ticket #{selectedTicket?.id}
        </DialogTitle>

        <DialogContent>
          <Typography variant="body2" sx={{ mb: 2 }}>
            Please upload the required document.
          </Typography>

          <input
            type="file"
            onChange={(e) => setFile(e.target.files[0])}
          />

          {file && (
            <Typography variant="body2" sx={{ mt: 1 }}>
              Selected: {file.name}
            </Typography>
          )}
        </DialogContent>

        <DialogActions>
          <Button onClick={() => setUploadOpen(false)}>
            Cancel
          </Button>

          <Button
            variant="contained"
            onClick={() => {
              alert("File uploaded successfully (Demo)");
              setUploadOpen(false);
              setFile(null);
            }}
          >
            Upload
          </Button>
        </DialogActions>
      </Dialog>

    </Box>
  );
}
