// import React from "react";
// import { Box } from "@mui/material";
// import { DataGrid } from "@mui/x-data-grid";

// export default function TicketGrid({ onTicketClick }) {
//   const rows = [
//     { id: 101, title: "Login Issue", status: "Created", date: "14-Feb-2026" },
//     { id: 102, title: "Report Error", status: "Assigned", date: "20-Mar-2026" },
//     { id: 103, title: "Upload Error", status: "Pending", date: "25-Apr-2026" },
//     { id: 104, title: "Server Crash", status: "Created", date: "28-Apr-2026" },
//     { id: 105, title: "UI Bug", status: "Assigned", date: "02-May-2026" },
//     { id: 106, title: "Database Error", status: "Pending", date: "05-May-2026" }
//   ];

//   const columns = [
//     { field: "id", headerName: "Ticket-ID", flex: 1, align: "center", headerAlign: "center" },
//     { field: "title", headerName: "Title", flex: 2, align: "center", headerAlign: "center" },
//     { field: "status", headerName: "Status", flex: 1, align: "center", headerAlign: "center" },
//     { field: "date", headerName: "Expected-Comp-Date", flex: 1, align: "center", headerAlign: "center" }
//   ];

//   return (
//     <Box
//       sx={{
//         height: 360,
//         borderRadius: 2,
//         boxShadow: "0 6px 20px rgba(0,0,0,0.06)",
//         backgroundColor: "#f9f9f9"
//       }}
//     >
//       <DataGrid
//         rows={rows}
//         columns={columns}
//         hideFooter
//         disableRowSelectionOnClick
//         onRowClick={(params) => onTicketClick(params.row)}
//         sx={{
//           border: "none",
//           cursor: "pointer",

//           "& .MuiDataGrid-columnHeaders": {
//             backgroundColor: "#1e3a8a",
//             color: "#1d1515",
//             fontWeight: 600
//           },

//           "& .MuiDataGrid-row:nth-of-type(odd)": {
//             backgroundColor: "#f5f7ff"
//           },

//           "& .MuiDataGrid-row:hover": {
//             backgroundColor: "#dbeafe"
//           },

//           "& .MuiDataGrid-columnSeparator": {
//             display: "none"
//           }
//         }}
//       />
//     </Box>
//   );
// }
import React from "react";
import { Box } from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import ChatIcon from "@mui/icons-material/Chat";
import { Badge } from "@mui/material";

export default function TicketGrid({ onTicketClick }) {
const rows = [
  { id: 101, title: "Login Issue", status: "Created", date: "14-Feb-2026", unread: 2 },
  { id: 102, title: "Report Error", status: "Assigned", date: "20-Mar-2026", unread: 0 },
  { id: 103, title: "Upload Error", status: "Pending", date: "25-Apr-2026", unread: 5 },
  { id: 104, title: "Server Crash", status: "Attachment Required", date: "28-Apr-2026", unread: 1 },
  { id: 103, title: "Upload Error", status: "Pending", date: "25-Apr-2026", unread: 5 },
  { id: 104, title: "Server Crash", status: "Attachment Required", date: "28-Apr-2026", unread: 1 },
];


  const columns = [
    { field: "id", headerName: "Ticket-ID", flex: 1, align: "center", headerAlign: "center" },
    { field: "title", headerName: "Title", flex: 2, align: "center", headerAlign: "center" },
    { field: "status", headerName: "Status", flex: 1, align: "center", headerAlign: "center" },
    { field: "date", headerName: "Expected-Comp-Date", flex: 1, align: "center", headerAlign: "center" },
    {
  field: "unread",
  headerName: "Messages",
  flex: 1,
  align: "center",
  headerAlign: "center",
  renderCell: (params) => (
    <Badge
      badgeContent={params.value}
      color="error"
      invisible={params.value === 0}
    >
      <ChatIcon />
    </Badge>
  )
}

  ];

  return (
    <Box
      sx={{
        height: 360, 
        borderRadius: 2,
        boxShadow: "0 6px 20px rgba(0,0,0,0.06)",
        backgroundColor: "#f9f9f9"
      }}
    >
      <DataGrid
        rows={rows}
        columns={columns}
        hideFooter
        disableRowSelectionOnClick
        onRowClick={(params) => onTicketClick(params.row)}  
        sx={{
          border: "none",

          // Header Styling
          "& .MuiDataGrid-columnHeaders": {
            backgroundColor: "#1e3a8a",
            color: "#0f0c0c",
            fontWeight: 600,
            fontSize: "15px"
          },

          "& .MuiDataGrid-columnHeader": {
            paddingTop: "12px",
            paddingBottom: "12px"
          },

          // Alternate Row Colors
          "& .MuiDataGrid-row:nth-of-type(odd)": {
            backgroundColor: "#d2ecbd38"
          },

          "& .MuiDataGrid-row:nth-of-type(even)": {
            backgroundColor: "#ffffff"
          },

          // Hover Effect
          "& .MuiDataGrid-row:hover": {
            backgroundColor: "#9299a344"
          },

          "& .MuiDataGrid-columnSeparator": {
            display: "none"
          }
        }}
      />
    </Box>
  );
}
