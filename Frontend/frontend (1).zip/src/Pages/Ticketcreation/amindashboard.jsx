import React from "react";
import { Box, Typography, Card, CardContent } from "@mui/material";
import { useNavigate } from "react-router-dom";

export default function AdminDashboard() {
  const navigate = useNavigate();

  const departments = [
    { name: "Accounts", open: 11, completed: 8 },
    { name: "MilkBill", open: 6, completed: 6 },
    { name: "Store", open: 5, completed: 3 },
  ];

  return (
    <Box
      sx={{
        minHeight: "100vh",
        background: "linear-gradient(to right, #f8f9ff, #eef1ff)",
        p: 6,
      }}
    >
      {/* 🔥 Header Section */}
      <Box textAlign="center" mb={6}>
        <Typography
          variant="h3"
          fontWeight={800}
          sx={{
            background: "linear-gradient(90deg, #6F60C1, #8f7df0)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
          }}
        >
          Welcome Admin 👋
        </Typography>

        <Typography
          variant="subtitle1"
          color="text.secondary"
          mt={2}
        >
          Here’s an overview of your department tickets
        </Typography>
      </Box>

      {/* 🔥 Department Cards */}
      <Box
        display="flex"
        justifyContent="center"
        gap={5}
        flexWrap="wrap"
      >
        {departments.map((dept, index) => (
          <Card
            key={index}
            onClick={() =>
              navigate(`/Drawer/tickets/${dept.name}`)
            }
            sx={{
              width: 280,
              borderRadius: 4,
              cursor: "pointer",
              backdropFilter: "blur(10px)",
              background: "rgba(255,255,255,0.7)",
              boxShadow: "0 10px 25px rgba(111, 96, 193, 0.15)",
              transition: "0.3s ease",
              "&:hover": {
                transform: "translateY(-8px)",
                boxShadow:
                  "0 20px 35px rgba(111, 96, 193, 0.25)",
              },
            }}
          >
            <CardContent sx={{ textAlign: "center", p: 4 }}>
              <Typography
                variant="h6"
                fontWeight={700}
                color="#6F60C1"
                gutterBottom
              >
                {dept.name}
              </Typography>

              <Box mt={3}>
                <Typography variant="body1">
                  Open Tickets
                </Typography>
                <Typography
                  variant="h5"
                  fontWeight={700}
                  color="#ff9800"
                >
                  {dept.open}
                </Typography>
              </Box>

              <Box mt={3}>
                <Typography variant="body1">
                  Completed Tickets
                </Typography>
                <Typography
                  variant="h5"
                  fontWeight={700}
                  color="#4caf50"
                >
                  {dept.completed}
                </Typography>
              </Box>
            </CardContent>
          </Card>
        ))}
      </Box>
    </Box>
  );
}
