import React from "react";
import { Grid } from "@mui/material";

import { Button } from "@mui/material";
import { LocalizationProvider, DatePicker } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";

export default function CloseticketFilter({ selectedDate, setSelectedDate }) {
  return (
    <Grid
      container
      justifyContent="flex-end"
      alignItems="center"
      spacing={2}
    >
      <Grid size="auto">
        <LocalizationProvider dateAdapter={AdapterDayjs}>
          <DatePicker
            label="Select Date"
            value={selectedDate}
            onChange={(newValue) => setSelectedDate(newValue)}
            slotProps={{
              textField: {
                size: "small",
                sx: { width: 190 }
              }
            }}
          />
        </LocalizationProvider>
      </Grid>

      <Grid size="auto">
        <Button
          variant="contained"
          size="small"
          color="success"
          sx={{
            px: 3,
            
         
          }}
        >
          Search
        </Button>
      </Grid>
    </Grid>
  );
}
