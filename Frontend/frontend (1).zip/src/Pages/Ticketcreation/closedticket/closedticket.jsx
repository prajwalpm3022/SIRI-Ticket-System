
import React, { useState } from "react";
import {
  Box,
  Typography,
  Paper,
  Drawer,
  IconButton,
  TextField,
  Button
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import dayjs from "dayjs";
import CloseticketFilter from "./closedticketfilter";
import ClosedTicketGrid from "./closedticketgrid";

export default function ClosedTickets() {

  const [selectedDate, setSelectedDate] = useState(dayjs());
  const [selectedTicket, setSelectedTicket] = useState(null);
  const [chatOpen, setChatOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [chatMessages, setChatMessages] = useState([]);

  const handleTicketClick = (ticket) => {
    setSelectedTicket(ticket);
    setChatMessages([]); // reset chat
    setChatOpen(true);
  };

  return (
    <Box sx={{ p: 2 }}>

      {/* Header */}
      <Paper
        sx={{
          p: 1,
          borderRadius: 2,
          mb: 2,
          color: "#c782f5"
        }}
      >
        <Typography variant="h4" fontWeight={600}>
          COMPLETED TICKETS
        </Typography>
      </Paper>
          <Box sx={{ mb: 4 }}>
      <CloseticketFilter
          selectedDate={selectedDate}
          setSelectedDate={setSelectedDate}
        />
      </Box>

      {/* Grid */}
      <ClosedTicketGrid onTicketClick={handleTicketClick} />

      {/* Drawer Popup */}
      <Drawer
        anchor="right"
        open={chatOpen}
        onClose={() => setChatOpen(false)}
      >
        <Box
          sx={{
            width: 350,
            p: 2,
            display: "flex",
            flexDirection: "column",
            height: "100%"
          }}
        >

          {/* Header */}
          <Box display="flex" justifyContent="space-between">
            <Typography variant="h6" fontWeight={600}>
              Ticket #{selectedTicket?.id}
            </Typography>
            <IconButton onClick={() => setChatOpen(false)}>
              <CloseIcon />
            </IconButton>
          </Box>

          {/* Remarks */}
          <Box sx={{ mt: 2, mb: 2 }}>
            <Typography variant="subtitle2">
              Remarks:
            </Typography>
            <Typography variant="body2" color="text.secondary">
              {selectedTicket?.remarks}
            </Typography>
          </Box>

          {/* Chat Area */}
          <Box
            sx={{
              flexGrow: 1,
              border: "1px solid #eee",
              borderRadius: 2,
              p: 2,
              overflowY: "auto",
              backgroundColor: "#f9f9f9",
              mb: 2
            }}
          >
            {chatMessages.length === 0 ? (
              <Typography variant="body2">
                👋 Start conversation with support.
              </Typography>
            ) : (
              chatMessages.map((msg, index) => (
                <Box
                  key={index}
                  sx={{
                    textAlign: msg.sender === "user" ? "right" : "left",
                    mb: 1
                  }}
                >
                  <Box
                    sx={{
                      display: "inline-block",
                      px: 2,
                      py: 1,
                      borderRadius: 2,
                      backgroundColor:
                        msg.sender === "user" ? "#1976d2" : "#e0e0e0",
                      color: msg.sender === "user" ? "#fff" : "#000"
                    }}
                  >
                    {msg.text}
                  </Box>
                </Box>
              ))
            )}
          </Box>

          {/* Input */}
          <Box display="flex" gap={1}>
            <TextField
              fullWidth
              size="small"
              placeholder="Type message..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
            />
            <Button
              variant="contained"
              onClick={() => {
                if (!message.trim()) return;

                setChatMessages(prev => [
                  ...prev,
                  { sender: "user", text: message }
                ]);

                setMessage("");

                // Fake support reply
                setTimeout(() => {
                  setChatMessages(prev => [
                    ...prev,
                    { sender: "support", text: "Support will contact you shortly." }
                  ]);
                }, 1000);
              }}
            >
              Send
            </Button>
          </Box>

        </Box>
      </Drawer>

    </Box>
  );
}
