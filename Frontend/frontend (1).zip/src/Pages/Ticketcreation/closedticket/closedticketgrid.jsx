import React from "react";
import { Box } from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";

export default function ClosedTicketGrid({ onTicketClick }) {
   const rows = [
    {
      id: 101,
      title: "Login Issue",
      expectdate: "14-Feb-2026",
      completedDate: "14-Feb-2026",
      remarks: "User unable to login due to password mismatch."
    },
    {
      id: 102,
      title: "Report Error",
      expectdate: "25-Apr-2026",
      completedDate: "20-Mar-2026",
      remarks: "Report export failing for large datasets."
    },
    {
      id: 103,
      title: "Upload Error",
      expectdate: "14-Feb-2026",
      completedDate: "25-Apr-2026",
      remarks: "File upload timing out."
    }
  ];

  const columns = [
    { field: "id", headerName: "Ticket-ID", flex: 1, align: "center", headerAlign: "center" },
    { field: "title", headerName: "Title", flex: 2, align: "center", headerAlign: "center" },
    { field: "expectdate", headerName: "Expected Date", flex: 1, align: "center", headerAlign: "center" },
    { field: "completedDate", headerName: "Completed Date", flex: 1, align: "center", headerAlign: "center" }

  ];

  return (
   <Box
  sx={{
    maxHeight: 400,          // set maximum height
    width: "100%",
    borderRadius: 2,
    boxShadow: "0 6px 20px rgba(0,0,0,0.06)",
    backgroundColor: "#f9f9f9",
    overflow: "hidden"
  }}
>
         <DataGrid
        rows={rows}
        columns={columns}
        hideFooter
        disableRowSelectionOnClick
        onRowClick={(params) => onTicketClick(params.row)}
        sx={{
          border: "none",
          cursor: "pointer",

          "& .MuiDataGrid-columnHeaders": {
            backgroundColor: "#1e3a8a",
          },

          "& .MuiDataGrid-columnHeaderTitle": {
            color: "#0c0b0b",
            fontWeight: 600
          },

          "& .MuiDataGrid-row:nth-of-type(odd)": {
            backgroundColor: "#dedcf7"
          },

          "& .MuiDataGrid-row:hover": {
            backgroundColor: "#dbeafe"
          },

          "& .MuiDataGrid-columnSeparator": {
            display: "none"
          }
        }}
     /> 
</Box>

  );
}
// import React from "react";
// import { Box } from "@mui/material";
// import { DataGrid } from "@mui/x-data-grid";

// export default function ClosedTicketGrid({ onTicketClick }) {

//   const rows = [
//     {
//       id: 101,
//       title: "Login Issue",
//       expectdate: "14-Feb-2026",
//       completedDate: "14-Feb-2026",
//       remarks: "User unable to login due to password mismatch."
//     },
//     {
//       id: 102,
//       title: "Report Error",
//       expectdate: "25-Apr-2026",
//       completedDate: "20-Mar-2026",
//       remarks: "Report export failing for large datasets."
//     },
//     {
//       id: 103,
//       title: "Upload Error",
//       expectdate: "14-Feb-2026",
//       completedDate: "25-Apr-2026",
//       remarks: "File upload timing out."
//     }
//   ];

//   const columns = [
//     { field: "id", headerName: "Ticket-ID", flex: 1, align: "center", headerAlign: "center" },
//     { field: "title", headerName: "Title", flex: 2, align: "center", headerAlign: "center" },
//     { field: "expectdate", headerName: "Expected Date", flex: 1, align: "center", headerAlign: "center" },
//     { field: "completedDate", headerName: "Completed Date", flex: 1, align: "center", headerAlign: "center" }
//   ];

//   return (
//     <Box
//       sx={{
//         height: 360,
//         borderRadius: 2,
//         boxShadow: "0 6px 20px rgba(0,0,0,0.06)",
//         backgroundColor: "#f9f9f9"
//       }}
//     >
//       <DataGrid
//         rows={rows}
//         columns={columns}
//         hideFooter
//         disableRowSelectionOnClick
//         onRowClick={(params) => onTicketClick(params.row)}
//         sx={{
//           border: "none",
//           cursor: "pointer",

//           "& .MuiDataGrid-columnHeaders": {
//             backgroundColor: "#1e3a8a",
//           },

//           "& .MuiDataGrid-columnHeaderTitle": {
//             color: "#fff",
//             fontWeight: 600
//           },

//           "& .MuiDataGrid-row:nth-of-type(odd)": {
//             backgroundColor: "#f5f7ff"
//           },

//           "& .MuiDataGrid-row:hover": {
//             backgroundColor: "#dbeafe"
//           },

//           "& .MuiDataGrid-columnSeparator": {
//             display: "none"
//           }
//         }}
//       />
//     </Box>
//   );
// }
