import React, { useState } from "react";
import {
  TextField,
  Button,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Box
} from "@mui/material";

import {Grid} from "@mui/material";

import { LocalizationProvider, DatePicker } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import dayjs from "dayjs";

const CreateTicket = () => {
  const [attachments, setAttachments] = useState([]);
  const [selectedDate, setSelectedDate] = useState(dayjs());

  const handleFileChange = (event) => {
    setAttachments(Array.from(event.target.files));
  };

  const handleClear = () => {
    setAttachments([]);
    setSelectedDate(dayjs());
  };

  return (
    <Box sx={{ background: "#f4f6f8", minHeight: "100vh", p: 5 }}>
      <Paper
        sx={{
          maxWidth: 1200,
          mx: "auto",
          p: 2,
          borderRadius: 3,
          boxShadow: "0 10px 30px rgba(0,0,0,0.05)"
        }}
      >
        <Typography variant="h5" fontWeight={600} mb={4}>
          Create Ticket
        </Typography>

        <Grid container spacing={5} alignItems="flex-start">

          {/* LEFT SIDE */}
          <Grid size={{ xs: 12, md: 7 }}>
            <Paper
              elevation={0}
              sx={{
                p: 2,
                borderRadius: 3,
                border: "1px solid #e5e7eb"
              }}
            >
              <Grid container spacing={3}>
                <Grid size={12}>
                  <TextField fullWidth label="Title" />
                </Grid>

             

                <Grid size={12}>
                  <TextField
                    fullWidth
                    label="Ticket Description"
                    multiline
                    rows={7}
                  />
                </Grid>
                   <Grid size={12}>
                  <LocalizationProvider dateAdapter={AdapterDayjs}>
                    <DatePicker
                      label="Expected Date of Completion"
                      value={selectedDate}
                      onChange={(newValue) => setSelectedDate(newValue)}
                      slotProps={{
                        textField: { fullWidth: true }
                      }}
                    />
                  </LocalizationProvider>
                </Grid>
              </Grid>
            </Paper>
          </Grid>

          {/* RIGHT SIDE */}
          <Grid size={{ xs: 12, md: 5 }}>
            <Paper
              elevation={0}
              sx={{
                p: 3,
                borderRadius: 3,
                border: "1px solid #e5e7eb"
              }}
            >
              <Typography fontWeight={600} mb={2}>
                Attach Documents
              </Typography>

              <Button
                fullWidth
                variant="contained"
                component="label"
                sx={{ mb: 3, borderRadius: 2 }}
              >
                Browse Documents
                <input
                  hidden
                  type="file"
                  multiple
                  onChange={handleFileChange}
                />
              </Button>

              <TableContainer
                sx={{
                  maxHeight: 300,
                  borderRadius: 2,
                  border: "1px solid #eee"
                }}
              >
                <Table size="small" stickyHeader>
                  <TableHead>
                    <TableRow>
                      <TableCell width="20%" sx={{ fontWeight: 600 }}>
                        No
                      </TableCell>
                      <TableCell sx={{ fontWeight: 600 }}>
                        Attachment Name
                      </TableCell>
                    </TableRow>
                  </TableHead>

                  <TableBody>
                    {attachments.length > 0 ? (
                      attachments.map((file, index) => (
                        <TableRow key={index} hover>
                          <TableCell>{index + 1}</TableCell>
                          <TableCell>{file.name}</TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={2} align="center">
                          No attachments added
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </TableContainer>
            </Paper>
          </Grid>

          {/* BUTTONS */}
          <Grid size={12}>
            <Box display="flex" justifyContent="flex-end" gap={2}>
              <Button variant="contained" color="success">
                Save Ticket
              </Button>

              <Button
                variant="contained"
                color="error"
                onClick={handleClear}
              >
                Clear
              </Button>
            </Box>
          </Grid>

        </Grid>
      </Paper>
    </Box>
  );
};

export default CreateTicket;
