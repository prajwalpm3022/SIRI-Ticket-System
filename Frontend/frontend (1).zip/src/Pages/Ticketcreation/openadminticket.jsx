import React, { useState } from "react";
import {
  Box,
  Typography,
  Card,
  Tabs,
  Tab,
  Paper,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  MenuItem,
  Select,
  FormControl,
  InputLabel
} from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import { useParams, useNavigate } from "react-router-dom";
import dayjs from "dayjs";

// DatePicker
import { LocalizationProvider, DatePicker } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";

export default function Tickets() {
  const { department } = useParams();
  const navigate = useNavigate();

  const [tab, setTab] = useState(0);
  const [selectedDate, setSelectedDate] = useState(null);
  const [searchDate, setSearchDate] = useState(null);

  // 🔥 Dialog States
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState(null);
  const [newStatus, setNewStatus] = useState("");
  const [selectedFile, setSelectedFile] = useState(null);

  // 🔥 CHAT STATES (ADDED)
  const [openChat, setOpenChat] = useState(false);
  const [chatMessage, setChatMessage] = useState("");
  const [chatStore, setChatStore] = useState({});

  const tickets = [
    {
      id: 1,
      department: "Accounts",
      title: "Login Issue",
      status: "NEW",
      expectedDate: "2026-02-15",
      attachment: "error.png"
    },
    {
      id: 2,
      department: "Accounts",
      title: "Payment Issue",
      status: "COMPLETED",
      expectedDate: "2026-02-10",
      completedDate: "2026-02-12",
      attachment: "payment.pdf"
    },
    {
      id: 3,
      department: "MilkBill",
      title: "Milk Entry Error",
      status: "NEW",
      expectedDate: "2026-02-16"
    }
  ];

  // 🔥 Filter Logic
  const getRows = () => {
    let filtered = tickets.filter(
      (t) => t.department === department
    );

    if (tab === 0) {
      filtered = filtered.filter((t) => t.status === "NEW");

      if (searchDate) {
        filtered = filtered.filter(
          (t) =>
            dayjs(t.expectedDate).format("YYYY-MM-DD") ===
            dayjs(searchDate).format("YYYY-MM-DD")
        );
      }
    }

    if (tab === 1) {
      filtered = filtered.filter((t) => t.status === "COMPLETED");

      if (searchDate) {
        filtered = filtered.filter(
          (t) =>
            dayjs(t.completedDate).format("YYYY-MM-DD") ===
            dayjs(searchDate).format("YYYY-MM-DD")
        );
      }
    }

    return filtered;
  };

  const openColumns = [
    { field: "id", headerName: "Ticket ID", width: 120 },
    { field: "title", headerName: "Title", flex: 1 },
    { field: "status", headerName: "Status", width: 150 },
    {
      field: "expectedDate",
      headerName: "Expected Date",
      width: 180,
      renderCell: (params) =>
        dayjs(params.value).format("DD-MMM-YYYY"),
    }
  ];

  const completedColumns = [
    { field: "id", headerName: "Ticket ID", width: 120 },
    { field: "title", headerName: "Title", flex: 1 },
    { field: "status", headerName: "Status", width: 150 },
    {
      field: "expectedDate",
      headerName: "Expected Date",
      width: 180,
      renderCell: (params) =>
        dayjs(params.value).format("DD-MMM-YYYY"),
    },
    {
      field: "completedDate",
      headerName: "Completed Date",
      width: 180,
      renderCell: (params) =>
        dayjs(params.value).format("DD-MMM-YYYY"),
    }
  ];

  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <Box p={5} bgcolor="#f6f7fb" minHeight="100vh">
        <Typography variant="h5" fontWeight={700} mb={3}>
          {department} Department Tickets
        </Typography>

        <Card sx={{ borderRadius: 3, p: 3, boxShadow: 4 }}>
          <Tabs
            value={tab}
            onChange={(e, v) => {
              setTab(v);
              setSelectedDate(null);
              setSearchDate(null);
            }}
          >
            <Tab label="Open Tickets" />
            <Tab label="Completed Tickets" />
          </Tabs>

          {/* Date Filter */}
          <Box
            display="flex"
            justifyContent="flex-end"
            alignItems="center"
            gap={2}
            mt={3}
          >
            <DatePicker
              label="Select Date"
              value={selectedDate}
              onChange={(newValue) => setSelectedDate(newValue)}
              slotProps={{
                textField: {
                  size: "small",
                  sx: { minWidth: 200, backgroundColor: "white" }
                }
              }}
            />

            <Button
              variant="contained"
              color="success"
              onClick={() => setSearchDate(selectedDate)}
            >
              Search
            </Button>

            <Button
              variant="contained"
              color="error"
              onClick={() => {
                setSelectedDate(null);
                setSearchDate(null);
              }}
            >
              Clear
            </Button>
          </Box>

          <Paper sx={{ height: 450, mt: 3 }}>
            <DataGrid
              rows={getRows()}
              columns={tab === 0 ? openColumns : completedColumns}
              hideFooter
              disableRowSelectionOnClick
              onRowClick={(params) => {
                setSelectedTicket(params.row);
                setNewStatus(params.row.status);
                setOpenDialog(true);
              }}
            />
          </Paper>
        </Card>

        {/* UPDATE POPUP */}
            <Dialog
  open={openDialog}
  onClose={() => setOpenDialog(false)}
  maxWidth="sm"
  fullWidth
  PaperProps={{
    sx: {
      borderRadius: 4,
      boxShadow: "0 20px 40px rgba(0,0,0,0.15)",
    },
  }}
>
  {/* 🔥 Header */}
  <DialogTitle
    sx={{
      background: "linear-gradient(90deg, #6F60C1, #8f7df0)",
      color: "white",
      fontWeight: 700,
      fontSize: "18px",
      borderTopLeftRadius: 16,
      borderTopRightRadius: 16,
    }}
  >
    Update Ticket - #{selectedTicket?.id}
  </DialogTitle>

  <DialogContent sx={{ mt: 3 }}>

    {/* Existing Attachment */}
    <Box
      sx={{
        p: 2,
        borderRadius: 2,
        backgroundColor: "#f4f3ff",
        mb: 3,
      }}
    >
      <Typography variant="subtitle2" fontWeight={600}>
        Existing Attachment
      </Typography>

      <Typography variant="body2" color="text.secondary">
        {selectedTicket?.attachment || "No attachment uploaded"}
      </Typography>
    </Box>

    {/* Upload Section */}
    <Box
      sx={{
        border: "2px dashed #d1d5ff",
        borderRadius: 3,
        p: 3,
        textAlign: "center",
        mb: 3,
        backgroundColor: "#fafaff",
      }}
    >
      <Button
        variant="contained"

        component="label"
        sx={{
          borderRadius: 2,
          px: 4,
          background: "linear-gradient(90deg, #6F60C1, #8f7df0)",
        }}
      >
        Browse File
        <input
          type="file"
          hidden
          onChange={(e) =>
            setSelectedFile(e.target.files[0])
          }
        />
      </Button>

      {selectedFile && (
        <Typography
          variant="body2"
          sx={{ mt: 2, color: "#6F60C1" }}
        >
          Selected: {selectedFile.name}
        </Typography>
      )}
    </Box>

    {/* Status Dropdown */}
    <FormControl fullWidth>
      <InputLabel>Status</InputLabel>
      <Select
        value={newStatus}
        label="Status"
        onChange={(e) =>
          setNewStatus(e.target.value)
        }
        sx={{
          borderRadius: 2,
          backgroundColor: "#fafaff",
        }}
      >
        <MenuItem value="NEW">NEW</MenuItem>
        <MenuItem value="ASSIGNED">ASSIGNED</MenuItem>
        <MenuItem value="COMPLETED">COMPLETED</MenuItem>
      </Select>
    </FormControl>

  </DialogContent>

  {/* Actions */}
  <DialogActions sx={{ p: 3 }}>
    
     <Button
              variant="contained"
              color="s"
              sx={{ borderRadius: 2 }}
              onClick={() => setOpenChat(true)}
            >
              Chat
            </Button>

    <Button
      variant="contained"
      color="success"
      sx={{
        borderRadius: 2,
        px: 4,
        background: "linear-gradient(90deg, #6F60C1, #8f7df0)",
      }}
      onClick={() => {
        alert("Ticket Updated Successfully (Demo)");
        setOpenDialog(false);
      }}
    >
      Update
    </Button>
    <Button
      variant="contained"
      color="error"
      sx={{ borderRadius: 2 }}
      onClick={() => {
        setSelectedFile(null);
        setNewStatus(selectedTicket?.status);
      }}
    >
      Clear
    </Button>
  </DialogActions>
</Dialog>

        {/* 🔥 CHAT DIALOG */}
        <Dialog
          open={openChat}
          onClose={() => setOpenChat(false)}
          maxWidth="sm"
          fullWidth
        >
          <DialogTitle>
            Ticket Chat - #{selectedTicket?.id}
          </DialogTitle>

          <DialogContent>
            <Box
              sx={{
                height: 300,
                overflowY: "auto",
                backgroundColor: "#f5f5f5",
                p: 2,
                borderRadius: 2,
                mb: 2,
              }}
            >
              {(chatStore[selectedTicket?.id] || []).map(
                (msg, index) => (
                  <Box
                    key={index}
                    sx={{
                      textAlign:
                        msg.sender === "admin"
                          ? "right"
                          : "left",
                      mb: 1,
                    }}
                  >
                    <Box
                      sx={{
                        display: "inline-block",
                        px: 2,
                        py: 1,
                        borderRadius: 2,
                        backgroundColor:
                          msg.sender === "admin"
                            ? "#6F60C1"
                            : "#e0e0e0",
                        color:
                          msg.sender === "admin"
                            ? "white"
                            : "black",
                      }}
                    >
                      {msg.text}
                      <Typography
                        variant="caption"
                        display="block"
                      >
                        {msg.time}
                      </Typography>
                    </Box>
                  </Box>
                )
              )}
            </Box>

            <Box display="flex" gap={1}>
              <input
                type="text"
                value={chatMessage}
                onChange={(e) =>
                  setChatMessage(e.target.value)
                }
                style={{
                  flex: 1,
                  padding: "10px",
                  borderRadius: "8px",
                  border: "1px solid #ccc",
                }}
                placeholder="Type message..."
              />

              <Button
                variant="contained"
                onClick={() => {
                  if (!chatMessage.trim()) return;

                  const ticketId = selectedTicket?.id;

                  setChatStore({
                    ...chatStore,
                    [ticketId]: [
                      ...(chatStore[ticketId] || []),
                      {
                        sender: "admin",
                        text: chatMessage,
                        time: dayjs().format("HH:mm"),
                      },
                    ],
                  });

                  setChatMessage("");

                  setTimeout(() => {
                    setChatStore((prev) => ({
                      ...prev,
                      [ticketId]: [
                        ...(prev[ticketId] || []),
                        {
                          sender: "user",
                          text: "User received your message 👍",
                          time: dayjs().format("HH:mm"),
                        },
                      ],
                    }));
                  }, 1000);
                }}
              >
                Send
              </Button>
            </Box>
          </DialogContent>
        </Dialog>

        <Box mt={3}>
          <Typography
            color="#6F60C1"
            sx={{ cursor: "pointer" }}
            onClick={() =>
              navigate("/Drawer/admindashboard")
            }
          >
            ← Back to Dashboard
          </Typography>
        </Box>
      </Box>
    </LocalizationProvider>
  );
}